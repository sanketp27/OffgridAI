# Catalogue Parser

Multi-format product catalogue parser: PDF, DOCX, XLSX, and raw images all
converge on one normalized product schema via a shared Gemini structuring
engine.

## Architecture

```
File --> sniff_source_type() [content bytes, not extension]
              |
    +---------+---------+---------+
    |         |         |         |
   PDF      DOCX      XLSX      Image
    |         |         |         |
 PyMuPDF   python-docx openpyxl   PIL
 (xref     (zip        (cell-    (no text
 images +  media/ +    anchored  layer --
 geometry) doc order)  images -- deferred
                        exact)   to Gemini)
    |         |         |         |
    +---------+---------+---------+
              |
     RawExtraction (shared contract)
              |
     GeminiStructurer
     - Flash for bulk structuring (cheap)
     - Pro only for: raw images, ambiguous PDF image<->SKU adjudication
              |
     validate_batch()
     - schema rules, content-hash dedup, hard-fail exclusion
              |
     ProductService.upsert_batch()
     - idempotent on content_hash
```

## Why each format is handled differently

| Format | Image source | Association confidence |
|---|---|---|
| XLSX | `openpyxl` cell-anchored floating images | Exact — deterministic, no LLM needed |
| DOCX | zip `word/media/` + document-order proximity | High — DOCX preserves reading order |
| PDF | PyMuPDF xref extraction + bounding-box geometry | Variable — ambiguous layouts escalate to Gemini Pro; scanned pages with no extractable image objects fall back to full-page rasterization |
| Raw image | The image itself | N/A — one multimodal Gemini call does OCR + attribute extraction directly |

## Setup

```bash
pip install -r requirements.txt
export GEMINI_API_KEY="your-key-here"
```

## Usage

```python
from pathlib import Path
from pipeline import run_pipeline

result = run_pipeline(Path("catalogue.xlsx"))
print(result.success_count, "products created")
print(result.warnings)  # low-confidence images, missing images, etc.
```

## Project layout

```
schema/models.py           Pydantic contract: RawExtraction, Product, etc.
extractors/base.py         Content-sniffing router (not extension-based)
extractors/pdf_extractor.py
extractors/docx_extractor.py
extractors/xlsx_extractor.py
extractors/image_extractor.py
services/gemini_structurer.py   Shared structuring engine, cost-tiered routing
services/validator.py           Business rules + idempotency hashing
services/product_service.py     Upsert layer (swap for real DB in production)
pipeline.py                     Single entry point: run_pipeline(file_path)
tests/                          Fixtures used during development
```

## Known limitations / production TODOs

- `ProductService` is in-memory — wire to Cloud SQL / Firestore for real use.
- `CandidateImage.storage_uri` is unset by extractors — production code
  should persist extracted image bytes to GCS immediately after extraction
  and populate this field before the Gemini structuring stage.
- `_attach_by_sequence` (DOCX) uses a simplified "first product lacking an
  image" heuristic — production should track paragraph index per product
  title for precise sequential association on documents with many products.
- PDF adjudication (`_adjudicate_pdf_images`) matches on product *title*
  returned from Gemini's JSON — for catalogues with duplicate/similar
  titles, key on a temporary per-page SKU index instead.
- No retry/backoff around Gemini calls — add before production use.
