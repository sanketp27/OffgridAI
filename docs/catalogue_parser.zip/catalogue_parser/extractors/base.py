"""Common interface every format extractor implements, plus the router that
dispatches by sniffed content type (not file extension — extensions lie)."""
from __future__ import annotations

import abc
import zipfile
from pathlib import Path

from schema.models import RawExtraction, SourceType


class BaseExtractor(abc.ABC):
    source_type: SourceType

    @abc.abstractmethod
    def extract(self, file_path: Path) -> RawExtraction:
        ...


def sniff_source_type(file_path: Path) -> SourceType:
    """
    Detect real file type by content signature, not extension.
    DOCX and XLSX are both zip containers — must inspect internals to tell
    them apart. PDF has a magic header. Images are checked via Pillow.
    """
    with open(file_path, "rb") as f:
        header = f.read(8)

    if header.startswith(b"%PDF-"):
        return SourceType.PDF

    if header[:4] == b"PK\x03\x04":  # zip signature — docx or xlsx
        with zipfile.ZipFile(file_path) as z:
            names = z.namelist()
            if "xl/workbook.xml" in names:
                return SourceType.XLSX
            if "word/document.xml" in names:
                return SourceType.DOCX
        raise ValueError(f"Unrecognized zip-based office file: {file_path}")

    try:
        from PIL import Image
        with Image.open(file_path) as img:
            img.verify()
        return SourceType.IMAGE
    except Exception:
        pass

    raise ValueError(f"Could not determine file type for: {file_path}")


class ExtractorRouter:
    """Dispatches a file to the right extractor based on sniffed content type."""

    def __init__(self) -> None:
        # populated lazily to avoid circular imports; see get()
        self._registry: dict[SourceType, BaseExtractor] = {}

    def _lazy_init(self) -> None:
        if self._registry:
            return
        from extractors.pdf_extractor import PdfExtractor
        from extractors.docx_extractor import DocxExtractor
        from extractors.xlsx_extractor import XlsxExtractor
        from extractors.image_extractor import ImageExtractor

        self._registry = {
            SourceType.PDF: PdfExtractor(),
            SourceType.DOCX: DocxExtractor(),
            SourceType.XLSX: XlsxExtractor(),
            SourceType.IMAGE: ImageExtractor(),
        }

    def route(self, file_path: Path) -> RawExtraction:
        self._lazy_init()
        source_type = sniff_source_type(file_path)
        extractor = self._registry.get(source_type)
        if extractor is None:
            raise ValueError(f"No extractor registered for {source_type}")
        return extractor.extract(file_path)
