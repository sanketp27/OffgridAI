"""
DOCX lane.

Text: python-docx walks paragraphs and tables in document order — DOCX
preserves reading order reliably (unlike PDF, which can have absolutely
positioned content that doesn't match visual order).

Images: DOCX is a zip archive; embedded images live under word/media/ as
plain files. We extract them directly rather than rendering pages, and
track each image's position in the document body (its paragraph index)
so association is sequential-proximity rather than geometric-guessing.
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from PIL import Image

from extractors.base import BaseExtractor
from schema.models import CandidateImage, RawExtraction, SourceType

MIN_IMAGE_DIM = 60  # px — filters icons/bullets, not legitimate small product photos


class DocxExtractor(BaseExtractor):
    source_type = SourceType.DOCX

    def extract(self, file_path: Path) -> RawExtraction:
        warnings: list[str] = []
        text_blocks: list[str] = []
        candidate_images: list[CandidateImage] = []

        doc = Document(str(file_path))

        # Map relationship id -> media filename, so we can tie an inline
        # image reference back to its actual bytes in word/media/.
        rel_to_media = {
            rel_id: rel.target_ref.split("/")[-1]
            for rel_id, rel in doc.part.rels.items()
            if "image" in rel.reltype
        }

        media_bytes = self._read_media(file_path)

        for para_index, para in enumerate(doc.paragraphs):
            text = para.text.strip()
            if text:
                text_blocks.append(text)

            for rel_id in self._inline_image_rel_ids(para):
                media_name = rel_to_media.get(rel_id)
                if not media_name or media_name not in media_bytes:
                    continue
                img_bytes = media_bytes[media_name]
                width, height = self._dimensions(img_bytes)
                if width < MIN_IMAGE_DIM or height < MIN_IMAGE_DIM:
                    continue  # filter icons/bullets by pixel size, not file size —
                    # a legitimately small but real product photo can still
                    # compress to a tiny byte count, so byte-size alone is
                    # not a reliable decorative-image signal
                candidate_images.append(
                    CandidateImage(
                        image_id=f"para{para_index}_{media_name}",
                        source_ref=f"docx_order:{para_index}",
                        width=width,
                        height=height,
                        storage_uri=None,  # caller persists img_bytes separately
                    )
                )

        # Tables often carry SKU/spec rows in catalogues — surface as text too
        for table in doc.tables:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells]
                if any(cells):
                    text_blocks.append(" | ".join(cells))

        if not candidate_images:
            warnings.append("no images found in word/media/")

        return RawExtraction(
            source_type=SourceType.DOCX,
            source_name=file_path.name,
            raw_text_blocks=text_blocks,
            markdown="\n\n".join(text_blocks),
            candidate_images=candidate_images,
            extraction_warnings=warnings,
        )

    def _inline_image_rel_ids(self, paragraph) -> list[str]:
        """Find r:embed relationship ids for any inline drawings in this paragraph."""
        rel_ids = []
        blips = paragraph._element.findall(
            ".//" + qn("a:blip")
        )
        for blip in blips:
            rel_id = blip.get(qn("r:embed"))
            if rel_id:
                rel_ids.append(rel_id)
        return rel_ids

    def _dimensions(self, img_bytes: bytes) -> tuple[int, int]:
        try:
            with Image.open(io.BytesIO(img_bytes)) as im:
                return im.size
        except Exception:
            return (0, 0)  # unreadable — filtered out by the dimension check above

    def _read_media(self, file_path: Path) -> dict[str, bytes]:
        media: dict[str, bytes] = {}
        with zipfile.ZipFile(file_path) as z:
            for name in z.namelist():
                if name.startswith("word/media/"):
                    media[name.split("/")[-1]] = z.read(name)
        return media
