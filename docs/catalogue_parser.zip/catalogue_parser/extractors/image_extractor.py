"""
Raw image lane — simplest case structurally, but ALL the reasoning work
shifts to Gemini since there's no separate text layer to extract from.

We don't try to OCR or classify here; we just package the image as the
single candidate and let the Gemini structuring engine do OCR + visual
attribute extraction (brand, color, category, any printed text) in one
multimodal call. Trying to pre-process this with a separate OCR library
would duplicate what Gemini already does natively and more robustly.
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image

from extractors.base import BaseExtractor
from schema.models import CandidateImage, RawExtraction, SourceType


class ImageExtractor(BaseExtractor):
    source_type = SourceType.IMAGE

    def extract(self, file_path: Path) -> RawExtraction:
        with Image.open(file_path) as img:
            width, height = img.size

        candidate = CandidateImage(
            image_id=file_path.stem,
            source_ref="direct_upload",
            width=width,
            height=height,
        )

        return RawExtraction(
            source_type=SourceType.IMAGE,
            source_name=file_path.name,
            raw_text_blocks=[],
            markdown="",  # nothing textual — Gemini reads the image directly
            candidate_images=[candidate],
        )
