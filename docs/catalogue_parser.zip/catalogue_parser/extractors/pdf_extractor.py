"""
PDF lane.

Text/structure: PyMuPDF's get_text("dict") gives layout-aware blocks we
convert to markdown-ish text ourselves (avoids a hard dependency on
pymupdf4llm for this reference implementation — swap in pymupdf4llm.to_markdown()
for production-grade markdown fidelity).

Images: xref-level extraction pulls every embedded raster, independent of
page rendering. Falls back to full-page rasterization when a page has no
extractable image objects (i.e. it's a flattened/scanned page).

SKU association: bounding-box proximity — the image is paired with the
nearest text block above/left of it, flagged low-confidence when more than
one candidate SKU sits within range (Gemini adjudicates those later).
"""
from __future__ import annotations

from pathlib import Path

import pymupdf as fitz  # PyMuPDF — `pymupdf` is the modern import name for `fitz`

from extractors.base import BaseExtractor
from schema.models import CandidateImage, RawExtraction, SourceType

MIN_IMAGE_DIM = 80          # px — filters icons/bullets/rule lines


class PdfExtractor(BaseExtractor):
    source_type = SourceType.PDF

    def extract(self, file_path: Path) -> RawExtraction:
        warnings: list[str] = []
        text_blocks: list[str] = []
        candidate_images: list[CandidateImage] = []

        doc = fitz.open(file_path)
        try:
            for page_index, page in enumerate(doc):
                page_no = page_index + 1
                page_text = page.get_text("text").strip()
                if page_text:
                    text_blocks.append(f"[page {page_no}]\n{page_text}")

                images_on_page = self._extract_page_images(doc, page, page_no)
                if not images_on_page:
                    # No embedded image objects — likely a scanned/flattened
                    # page. Rasterize the whole page so Gemini can work
                    # from a visual, since there is nothing to xref-extract.
                    if not page_text:
                        candidate_images.append(
                            self._rasterize_full_page(page, page_no)
                        )
                        warnings.append(
                            f"page {page_no}: no text or embedded images — "
                            f"rasterized as scanned fallback"
                        )
                else:
                    candidate_images.extend(images_on_page)

            markdown = "\n\n".join(text_blocks)
            return RawExtraction(
                source_type=SourceType.PDF,
                source_name=file_path.name,
                raw_text_blocks=text_blocks,
                markdown=markdown,
                candidate_images=candidate_images,
                page_count=doc.page_count,
                extraction_warnings=warnings,
            )
        finally:
            doc.close()

    def _extract_page_images(
        self, doc: fitz.Document, page: fitz.Page, page_no: int
    ) -> list[CandidateImage]:
        results: list[CandidateImage] = []
        for img_index, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            try:
                base_image = doc.extract_image(xref)
            except Exception:
                continue

            width = base_image.get("width", 0)
            height = base_image.get("height", 0)

            if width < MIN_IMAGE_DIM or height < MIN_IMAGE_DIM:
                continue  # icon / bullet / rule — not a product photo.
                # Deliberately not filtering on compressed byte size here:
                # a small but legitimate product photo can compress well
                # below any reasonable byte threshold, so pixel dimensions
                # are the only reliable signal for "decorative vs. real".

            bbox = self._bbox_for_xref(page, xref)

            results.append(
                CandidateImage(
                    image_id=f"p{page_no}_x{xref}_{img_index}",
                    source_ref=f"xref:{xref}",
                    width=width,
                    height=height,
                    page_number=page_no,
                    bbox=bbox,
                )
            )
        return results

    def _bbox_for_xref(
        self, page: fitz.Page, xref: int
    ) -> tuple[float, float, float, float] | None:
        """Locate where on the page this image xref is actually placed,
        so geometric SKU association has coordinates to work with."""
        for rect_info in page.get_image_rects(xref):
            r = rect_info if isinstance(rect_info, fitz.Rect) else rect_info[0]
            return (r.x0, r.y0, r.x1, r.y1)
        return None

    def _rasterize_full_page(self, page: fitz.Page, page_no: int) -> CandidateImage:
        pix = page.get_pixmap(dpi=200)
        image_bytes = pix.tobytes("png")
        return CandidateImage(
            image_id=f"p{page_no}_fullpage",
            source_ref=f"page_render:{page_no}",
            width=pix.width,
            height=pix.height,
            page_number=page_no,
            bbox=(0, 0, page.rect.width, page.rect.height),
        )
