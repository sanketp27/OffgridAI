"""
XLSX lane — the easiest image-association case of all four formats.

Excel embeds floating images with an explicit anchor: the cell range
they're pinned to. openpyxl exposes this via worksheet._images, each with
an .anchor giving the top-left cell. That means SKU<->image mapping is
exact and deterministic — no geometry heuristics, no Gemini adjudication
needed for this step. We only defer to Gemini for attribute normalization
(e.g. messy free-text columns -> structured fields), not for image linking.
"""
from __future__ import annotations

from pathlib import Path

import openpyxl

from extractors.base import BaseExtractor
from schema.models import CandidateImage, RawExtraction, SourceType


class XlsxExtractor(BaseExtractor):
    source_type = SourceType.XLSX

    def extract(self, file_path: Path) -> RawExtraction:
        warnings: list[str] = []
        table_rows: list[dict] = []
        candidate_images: list[CandidateImage] = []

        wb = openpyxl.load_workbook(file_path, data_only=True)
        ws = wb.active  # assume first/active sheet holds the catalogue

        headers = self._read_headers(ws)
        if not headers:
            warnings.append("no header row detected on active sheet")

        for row_idx, row in enumerate(
            ws.iter_rows(min_row=2, values_only=True), start=2
        ):
            if all(v is None for v in row):
                continue
            record = {
                headers[i]: row[i]
                for i in range(min(len(headers), len(row)))
                if headers[i]
            }
            record["_row_number"] = row_idx
            table_rows.append(record)

        # Cell-anchored images: exact row association via anchor row index
        for idx, img in enumerate(getattr(ws, "_images", [])):
            anchor_row = self._anchor_row(img)
            candidate_images.append(
                CandidateImage(
                    image_id=f"row{anchor_row}_img{idx}",
                    source_ref=f"cell_anchor:row{anchor_row}",
                    width=getattr(img, "width", None),
                    height=getattr(img, "height", None),
                )
            )

        if not candidate_images:
            warnings.append("no cell-anchored images found on active sheet")

        # Build a lightweight markdown table for the Gemini pass (attribute
        # normalization still benefits from LLM cleanup of messy columns)
        markdown = self._rows_to_markdown(headers, table_rows)

        return RawExtraction(
            source_type=SourceType.XLSX,
            source_name=file_path.name,
            markdown=markdown,
            candidate_images=candidate_images,
            table_rows=table_rows,
            extraction_warnings=warnings,
        )

    def _read_headers(self, ws) -> list[str]:
        first_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ())
        return [str(v).strip() if v else "" for v in first_row]

    def _anchor_row(self, img) -> int:
        """openpyxl anchor rows are 0-indexed; +1 to match spreadsheet row numbers."""
        try:
            return img.anchor._from.row + 1
        except AttributeError:
            return -1  # anchor shape not resolvable — flagged for review downstream

    def _rows_to_markdown(self, headers: list[str], rows: list[dict]) -> str:
        if not headers or not rows:
            return ""
        lines = ["| " + " | ".join(headers) + " |"]
        lines.append("|" + "---|" * len(headers))
        for r in rows:
            lines.append(
                "| " + " | ".join(str(r.get(h, "")) for h in headers) + " |"
            )
        return "\n".join(lines)
