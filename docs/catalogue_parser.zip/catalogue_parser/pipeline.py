"""
End-to-end pipeline. This is the single entry point production code (a
Cloud Run handler, a Cloud Tasks consumer, a CLI) should call — everything
upstream (routing, extraction, structuring, validation, storage) is
intentionally hidden behind this one function so the caller never needs to
know or care what file format it was given.

    result = run_pipeline(Path("catalogue.xlsx"))
    result = run_pipeline(Path("scanned_page.jpg"))
    result = run_pipeline(Path("brochure.pdf"))
"""
from __future__ import annotations

import uuid
from pathlib import Path

from extractors.base import ExtractorRouter
from schema.models import ParseJobResult
from services.gemini_structurer import GeminiStructurer
from services.product_service import ProductService
from services.validator import validate_batch


def run_pipeline(
    file_path: Path,
    structurer: GeminiStructurer | None = None,
    product_service: ProductService | None = None,
) -> ParseJobResult:
    job_id = str(uuid.uuid4())
    router = ExtractorRouter()
    structurer = structurer or GeminiStructurer()
    product_service = product_service or ProductService()

    # Stage 1 — route + extract (format-specific, converges on RawExtraction)
    extraction = router.route(file_path)

    # Stage 2 — structure via shared Gemini engine (source-agnostic from here on)
    try:
        products = structurer.structure(extraction)
    except Exception as e:
        return ParseJobResult(
            job_id=job_id,
            source_type=extraction.source_type,
            source_name=extraction.source_name,
            errors=[f"structuring failed: {e}"],
            warnings=extraction.extraction_warnings,
        )

    # Stage 3 — validate + hash for idempotency
    accepted, issues_by_sku = validate_batch(products)

    # Stage 4 — commit
    product_service.upsert_batch(accepted)

    warnings = list(extraction.extraction_warnings)
    for sku, issues in issues_by_sku.items():
        warnings.extend(f"{sku}: {issue}" for issue in issues)

    return ParseJobResult(
        job_id=job_id,
        source_type=extraction.source_type,
        source_name=extraction.source_name,
        products=accepted,
        warnings=warnings,
    )
