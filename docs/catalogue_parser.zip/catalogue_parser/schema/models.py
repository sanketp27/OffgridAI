"""
Platform data contract.

Every extractor (PDF, DOCX, XLSX, raw image, URL) must converge on these
models before reaching the Gemini structuring engine. This is what keeps
the pipeline source-agnostic: downstream code never needs to know whether
a product came from a spreadsheet or a crawled webpage.
"""
from __future__ import annotations

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, HttpUrl, field_validator


class SourceType(str, Enum):
    PDF = "pdf"
    DOCX = "docx"
    XLSX = "xlsx"
    IMAGE = "image"
    URL = "url"


class ImageAssociationMethod(str, Enum):
    """How confident / by what mechanism an image was linked to a SKU."""
    CELL_ANCHOR = "cell_anchor"          # xlsx — deterministic, exact
    DOCUMENT_ORDER = "document_order"    # docx — sequential proximity
    GEOMETRIC = "geometric"              # pdf — bounding-box proximity
    GEMINI_ADJUDICATED = "gemini_adjudicated"  # pdf/docx — LLM resolved ambiguity
    DIRECT = "direct"                    # raw image upload, url <img> — no inference needed
    UNRESOLVED = "unresolved"            # extraction succeeded but no image found


class CandidateImage(BaseModel):
    """An image pulled out during extraction, before it's confirmed as a product image."""
    image_id: str
    source_ref: str = Field(..., description="xref id, cell anchor, para index, or URL")
    width: Optional[int] = None
    height: Optional[int] = None
    page_number: Optional[int] = None
    bbox: Optional[tuple[float, float, float, float]] = None  # x0, y0, x1, y1 — PDF only
    storage_uri: Optional[str] = None  # GCS path once persisted
    perceptual_hash: Optional[str] = None
    is_decorative: bool = False  # logo/banner/watermark — filtered before Gemini


class RawExtraction(BaseModel):
    """
    Intermediate contract every format-specific extractor must produce.
    This is the hand-off point into the Gemini structuring engine.
    """
    source_type: SourceType
    source_name: str
    raw_text_blocks: list[str] = Field(default_factory=list)
    markdown: str = ""
    candidate_images: list[CandidateImage] = Field(default_factory=list)
    table_rows: list[dict] = Field(default_factory=list)  # for xlsx-native rows
    page_count: Optional[int] = None
    extraction_warnings: list[str] = Field(default_factory=list)


class ProductImage(BaseModel):
    url_or_uri: str
    association_method: ImageAssociationMethod
    confidence: float = Field(ge=0.0, le=1.0, default=1.0)


class Product(BaseModel):
    """Final normalized product record — the platform's canonical shape."""
    sku: str = Field(..., min_length=1)
    title: str = Field(..., min_length=1)
    description: Optional[str] = None
    price: Optional[float] = Field(default=None, ge=0)
    currency: Optional[str] = Field(default=None, max_length=3)
    category: Optional[str] = None
    attributes: dict[str, str] = Field(default_factory=dict)
    images: list[ProductImage] = Field(default_factory=list)
    source_type: SourceType
    source_name: str
    content_hash: Optional[str] = Field(
        default=None,
        description="Hash of sku+title+source used for idempotent re-ingestion",
    )

    @field_validator("currency")
    @classmethod
    def upper_currency(cls, v: Optional[str]) -> Optional[str]:
        return v.upper() if v else v


class ParseJobResult(BaseModel):
    job_id: str
    source_type: SourceType
    source_name: str
    products: list[Product] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)

    @property
    def success_count(self) -> int:
        return len(self.products)
