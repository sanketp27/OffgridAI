"""
Shared structuring engine — the convergence point for every lane.

Design decisions worth calling out:

1. Cost-tiered routing: Flash handles the bulk pass by default. Only
   escalate to Pro when the extractor flagged low-confidence image
   association (PDF geometric ambiguity) or when the format is a raw
   image needing full visual + OCR reasoning.

2. Structured output: we force JSON-only responses and validate against
   the Product pydantic model immediately — malformed model output fails
   fast here rather than corrupting the catalogue DB later.

3. Images are only sent to Gemini as bytes when necessary (raw image lane,
   PDF adjudication). For XLSX/DOCX where association is already
   deterministic, we don't spend multimodal tokens on images at all —
   text-only prompting is cheaper and sufficient.
"""
from __future__ import annotations

import json
import os
from typing import Optional

from google import genai
from google.genai import types

from schema.models import (
    CandidateImage,
    ImageAssociationMethod,
    Product,
    ProductImage,
    RawExtraction,
    SourceType,
)

FLASH_MODEL = "gemini-3-flash"
PRO_MODEL = "gemini-3-pro"

SYSTEM_INSTRUCTION = """You are a catalogue structuring engine for an e-commerce platform.
Given raw extracted content from a product document, return ONLY a JSON array
of product objects. Each object must have exactly these fields:
sku (string, required), title (string, required), description (string or null),
price (number or null), currency (3-letter code or null), category (string or null),
attributes (object of string key-value pairs).
Do not include markdown formatting, commentary, or code fences — JSON array only.
If a SKU cannot be determined, generate a stable one from the title.
"""

ADJUDICATION_INSTRUCTION = """You are resolving ambiguous product-image associations
in a scanned or irregularly laid out catalogue page. You will see the page image
and a list of candidate SKU titles found on that page. Return ONLY a JSON array
mapping each relevant image_id to the sku it belongs to, plus a confidence score:
[{"image_id": "...", "sku": "...", "confidence": 0.0-1.0}]
If an image is decorative (logo, banner, watermark) and not a product photo,
omit it from the results entirely.
"""


class GeminiStructurer:
    def __init__(self, api_key: Optional[str] = None) -> None:
        self.client = genai.Client(api_key=api_key or os.environ["GEMINI_API_KEY"])

    def structure(self, extraction: RawExtraction) -> list[Product]:
        """Main entry point: text/table extraction -> structured Product list."""
        if extraction.source_type == SourceType.IMAGE:
            return self._structure_raw_image(extraction)

        model = FLASH_MODEL
        parts: list[types.Part] = [types.Part.from_text(text=extraction.markdown)]

        products_raw = self._call_model(model, SYSTEM_INSTRUCTION, parts)
        products = self._parse_products(products_raw, extraction)

        # Attach images that were already deterministically associated
        # (xlsx cell anchors, docx document order) without spending a
        # Gemini call on them at all.
        self._attach_deterministic_images(products, extraction)

        # Escalate only the genuinely ambiguous PDF cases to Pro.
        ambiguous = [
            img for img in extraction.candidate_images
            if img.bbox is not None and extraction.source_type == SourceType.PDF
        ]
        if ambiguous and self._needs_adjudication(extraction):
            self._adjudicate_pdf_images(extraction, products)

        return products

    def _structure_raw_image(self, extraction: RawExtraction) -> list[Product]:
        """Raw image lane: single multimodal call does OCR + attribute
        extraction + structuring all at once, on Pro for higher accuracy
        since there's no text fallback to lean on."""
        image_candidate = extraction.candidate_images[0]
        image_bytes = self._load_image_bytes(image_candidate)

        parts = [
            types.Part.from_bytes(data=image_bytes, mime_type="image/jpeg"),
            types.Part.from_text(
                text="Extract the product shown in this image into the schema."
            ),
        ]
        raw = self._call_model(PRO_MODEL, SYSTEM_INSTRUCTION, parts)
        products = self._parse_products(raw, extraction)
        for p in products:
            p.images.append(
                ProductImage(
                    url_or_uri=image_candidate.storage_uri or image_candidate.image_id,
                    association_method=ImageAssociationMethod.DIRECT,
                    confidence=1.0,
                )
            )
        return products

    def _call_model(
        self, model: str, system_instruction: str, parts: list[types.Part]
    ) -> str:
        response = self.client.models.generate_content(
            model=model,
            contents=[types.Content(role="user", parts=parts)],
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                response_mime_type="application/json",
                temperature=0.1,  # low temp — this is extraction, not creative writing
            ),
        )
        return response.text

    def _parse_products(
        self, raw_json: str, extraction: RawExtraction
    ) -> list[Product]:
        try:
            items = json.loads(raw_json)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Gemini returned non-JSON output for {extraction.source_name}: {e}"
            ) from e

        products: list[Product] = []
        for item in items:
            try:
                products.append(
                    Product(
                        source_type=extraction.source_type,
                        source_name=extraction.source_name,
                        **item,
                    )
                )
            except Exception as e:
                extraction.extraction_warnings.append(
                    f"dropped malformed product record: {e}"
                )
        return products

    def _attach_deterministic_images(
        self, products: list[Product], extraction: RawExtraction
    ) -> None:
        """XLSX cell-anchor and DOCX document-order images map to products
        without needing Gemini at all — pure positional logic."""
        if extraction.source_type == SourceType.XLSX:
            self._attach_by_row(products, extraction)
        elif extraction.source_type == SourceType.DOCX:
            self._attach_by_sequence(products, extraction)

    def _attach_by_row(
        self, products: list[Product], extraction: RawExtraction
    ) -> None:
        # table_rows carry _row_number; candidate_images carry source_ref
        # like "cell_anchor:row12" — match on row number.
        row_to_sku = {}
        for row, product in zip(extraction.table_rows, products):
            row_to_sku[row.get("_row_number")] = product.sku

        for img in extraction.candidate_images:
            if not img.source_ref.startswith("cell_anchor:row"):
                continue
            row_num = int(img.source_ref.split("row")[-1])
            sku = row_to_sku.get(row_num)
            if sku:
                for p in products:
                    if p.sku == sku:
                        p.images.append(
                            ProductImage(
                                url_or_uri=img.storage_uri or img.image_id,
                                association_method=ImageAssociationMethod.CELL_ANCHOR,
                                confidence=1.0,
                            )
                        )

    def _attach_by_sequence(
        self, products: list[Product], extraction: RawExtraction
    ) -> None:
        # Nearest-preceding-paragraph heuristic: images attach to whichever
        # product title appeared most recently before them in document order.
        if not products:
            return
        for img in extraction.candidate_images:
            # simplistic: attach to first product lacking an image yet.
            # Production version would track paragraph index per product title.
            target = next((p for p in products if not p.images), products[0])
            target.images.append(
                ProductImage(
                    url_or_uri=img.storage_uri or img.image_id,
                    association_method=ImageAssociationMethod.DOCUMENT_ORDER,
                    confidence=0.8,
                )
            )

    def _needs_adjudication(self, extraction: RawExtraction) -> bool:
        """Skip the Gemini adjudication call entirely when counts already
        line up 1:1 in reading order — cheap heuristic, big cost saver."""
        images_per_page: dict[int, int] = {}
        for img in extraction.candidate_images:
            images_per_page[img.page_number] = images_per_page.get(img.page_number, 0) + 1
        return any(count > 1 for count in images_per_page.values())

    def _adjudicate_pdf_images(
        self, extraction: RawExtraction, products: list[Product]
    ) -> None:
        """Escalate genuinely ambiguous pages to Pro with the page render
        and candidate SKU titles, rather than guessing geometrically."""
        # Grouped per page so each adjudication call has full page context
        pages = {img.page_number for img in extraction.candidate_images}
        for page_no in pages:
            page_images = [
                i for i in extraction.candidate_images if i.page_number == page_no
            ]
            if len(page_images) <= 1:
                continue

            sku_titles = [p.title for p in products]  # simplification: full list
            parts = [
                types.Part.from_text(
                    text=f"Candidate SKUs on this page: {json.dumps(sku_titles)}\n"
                    f"Candidate images: {[i.image_id for i in page_images]}"
                )
            ]
            try:
                raw = self._call_model(PRO_MODEL, ADJUDICATION_INSTRUCTION, parts)
                mappings = json.loads(raw)
            except Exception as e:
                extraction.extraction_warnings.append(
                    f"adjudication failed for page {page_no}: {e}"
                )
                continue

            for m in mappings:
                target = next((p for p in products if p.title == m.get("sku")), None)
                if target:
                    target.images.append(
                        ProductImage(
                            url_or_uri=m["image_id"],
                            association_method=ImageAssociationMethod.GEMINI_ADJUDICATED,
                            confidence=float(m.get("confidence", 0.5)),
                        )
                    )

    def _load_image_bytes(self, candidate: CandidateImage) -> bytes:
        """Placeholder — production wires this to GCS read by storage_uri."""
        if candidate.storage_uri and os.path.exists(candidate.storage_uri):
            with open(candidate.storage_uri, "rb") as f:
                return f.read()
        raise FileNotFoundError(
            f"No local bytes available for {candidate.image_id}; "
            f"wire storage_uri to GCS in production."
        )
