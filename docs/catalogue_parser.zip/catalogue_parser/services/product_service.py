"""
Final stage: commits validated products to the catalogue store.

This reference implementation uses an in-memory dict keyed by content_hash
to demonstrate the upsert/idempotency contract. Swap _store for a real
Cloud SQL / Firestore client in production — the interface (upsert_batch)
stays the same either way.
"""
from __future__ import annotations

from schema.models import Product


class ProductService:
    def __init__(self) -> None:
        self._store: dict[str, Product] = {}  # content_hash -> Product

    def upsert_batch(self, products: list[Product]) -> dict[str, int]:
        created, updated = 0, 0
        for product in products:
            key = product.content_hash or product.sku
            if key in self._store:
                updated += 1
            else:
                created += 1
            self._store[key] = product
        return {"created": created, "updated": updated, "total_in_store": len(self._store)}

    def all_products(self) -> list[Product]:
        return list(self._store.values())

    def get_by_sku(self, sku: str) -> Product | None:
        for p in self._store.values():
            if p.sku == sku:
                return p
        return None
