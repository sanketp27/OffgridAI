"""
Validation layer sitting between the Gemini structuring engine and the
product creation service. Pydantic already enforces shape (types, required
fields) at construction time in Product — this layer adds business rules
that aren't expressible as field constraints, plus the idempotency hash
that keeps re-parsing a catalogue from spawning duplicate products.
"""
from __future__ import annotations

import hashlib

from schema.models import Product


class ValidationError(Exception):
    def __init__(self, sku: str, reason: str) -> None:
        self.sku = sku
        self.reason = reason
        super().__init__(f"[{sku}] {reason}")


def compute_content_hash(product: Product) -> str:
    """Stable hash for idempotent re-ingestion: same sku+title+source
    re-parsed later resolves to the same hash, so upserts don't duplicate."""
    basis = f"{product.sku}|{product.title}|{product.source_name}".lower().strip()
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()[:16]


def validate_product(product: Product) -> list[str]:
    """Returns a list of validation issues; empty list means valid.
    Non-fatal issues are warnings the caller can choose to act on."""
    issues: list[str] = []

    if not product.sku.strip():
        issues.append("empty SKU after structuring")

    if len(product.title) < 2:
        issues.append("title too short to be meaningful")

    if product.price is not None and product.price <= 0:
        issues.append("price must be positive if present")

    if product.images and any(
        img.confidence < 0.4 for img in product.images
    ):
        issues.append("at least one image has low association confidence — flag for review")

    if not product.images:
        issues.append("no image associated — acceptable but flagged for manual follow-up")

    return issues


def validate_batch(products: list[Product]) -> tuple[list[Product], dict[str, list[str]]]:
    """
    Splits a batch into (accepted, warnings_by_sku). Hard failures (empty
    SKU, empty title) and in-batch duplicates (same content_hash) are
    excluded from accepted — duplicates are deliberately dropped here
    rather than passed through, since letting both copies reach
    ProductService.upsert_batch would rely on the store's own keying to
    quietly de-duplicate, masking the issue instead of reporting it once
    per real record. Everything else passes through with warnings attached
    for downstream review queues. warnings_by_sku uses a list per SKU so a
    genuine duplicate SKU (two distinct products/content_hash sharing one
    SKU) doesn't have one record's issues silently overwrite the other's.
    """
    accepted: list[Product] = []
    warnings_by_sku: dict[str, list[str]] = {}
    seen_hashes: set[str] = set()

    for product in products:
        product.content_hash = compute_content_hash(product)
        issues = validate_product(product)

        hard_fail = not product.sku.strip() or len(product.title) < 2
        if hard_fail:
            _append_issues(warnings_by_sku, product.sku or "<empty>", issues)
            continue

        if product.content_hash in seen_hashes:
            issues.append("dropped as duplicate within this batch — same content hash")
            _append_issues(warnings_by_sku, product.sku, issues)
            continue
        seen_hashes.add(product.content_hash)

        if issues:
            _append_issues(warnings_by_sku, product.sku, issues)
        accepted.append(product)

    return accepted, warnings_by_sku


def _append_issues(
    warnings_by_sku: dict[str, list[str]], sku: str, issues: list[str]
) -> None:
    """Accumulate rather than overwrite, so a repeated SKU across records
    doesn't hide an earlier record's issues behind a later one's."""
    warnings_by_sku.setdefault(sku, []).extend(issues)
